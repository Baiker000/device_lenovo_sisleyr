/*
 * This file is automatic generated,
 * please do not make modification
 */

static const char daemon_version_str[] = "3.0.37";
static const char hal_version_str[] = "3.0.15";
static const char date_str[] = "2016-02-13 02:03:07";
const char* get_daemon_version(void)
{
	return daemon_version_str;
}
const char* get_hal_version(void)
{
	return hal_version_str;
}
const char* get_build_date(void)
{
	return date_str;
}

